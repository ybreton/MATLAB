 function sd = RRInit(varargin)
 
% sd = RRInit(fd)
%
% Initializes a single restaurant row session.
% checks and loads keys, video-tracker-1, and spikes
%
% ADR 2011-12
% 
% Optional arguments:
% ******************
% fd = pwd;              % file directory to initialize
% useKeys = true;        % use the _keys.m file
% useEvents = false;     % use the events.nev file
% timeBase = 1e-6;       % multiplier to get .nvt time stamps into seconds
% VTEtime = 3;           % time interval for VTE calculations (sec)
% 
% Behavior = [];         % the behavioral task
% Tones = true;          % tones
% Condition = '';        % experimental condition (Saline, drug, etc.)
% Dose = [];             % dose for experimental condition (mg/kg)
% Protocol = [];         % behavior, hyperdrive recording, pharmacology, etc
% Target = [];           % tetrode target structure (e.g. HC, OFC, vStr)
% Target2 = [];          % second tetrode target structure
% Target3 = [];          % third tetrode target structure
% Target4 =[];           % first target substructure
% Target5=[];            % second target substructure
% Target6=[];            % third target substructure
% TetrodeDepths = [];    % estimated depth turned of each tetrode in microns
% CSCReference = [];     % reference for each CSC
% UseDepthCSV = [];      % Use a csv containing depths for tetrodes
% TetrodeTargets = [];   % Index indicates which target
% nCSCs = 24;            % Number of continuous sampling channels (Typically 24)
% TimeOnTrack = [];      % Time on track
% TimeOffTrack = [];     % Time off track
% nSecGap = 25;          % number of seconds in recording gap to presume session has ended.
% HasHCTheta = [];       % 1 indicates an auxiliary HC theta electrode was included.  This affects the patch panel configuration on Cheetah.
% ThetaCSC = [];         % CSC channel of auxiliary HC theta electrode.
% PostFeed = [];         % Amount post-fed, in grams
% nPellets = [];         % the number of pellets delivered at each zone
% FeederDelayList = 1:30;% the delay of each zone
% FeederProbList = 1;    % the probability of reward in each zone
% Blocks = [];           % Number of times blocked
% Nudges = [];           % Number of times nudged
% Weight = [];           % the weight of the rat in grams
% Note1=[];              % document any unusual events, task malfunctions, or unusual behavior (e.g. lost tracking lap 20, feeder misfires lap 20, ghost pixels, rat fell off track lap 20 etc).
% Note2=[];
% Note3=[];
% addUnderscored=false;  % include underscored tetrode files (._t) in sd as sd.S_t, sd.fc_t, sd.fn_t fields. 
% 
% MODIFIED:
% 2014-10-29    (YAB)    Included field "World" with subfields
%                        FeederLocations, ZoneLocations, and MazeCenter.
% 

fd = pwd;
if nargin==1
    fd = varargin{1};
end
useKeys = true;
useEvents = false;
timeBase = 1e-6;
VTEtime = 3;           % time interval for VTE calculations (sec)

Behavior = [];         % the behavioral task
Tones = true;          % tones
Condition = '';        % experimental condition (Saline, drug, etc.)
Dose = [];             % dose for experimental condition (mg/kg)
Protocol = [];         % behavior, hyperdrive recording, pharmacology, etc
Target = [];           % tetrode target structure (e.g. HC, OFC, vStr)
Target2 = [];          % second tetrode target structure
Target3 = [];          % third tetrode target structure
Target4 =[];
Target5=[];
Target6=[];
TetrodeDepths = [];  % estimated depth turned of each tetrode in microns
CSCReference = [];   % reference for each CSC
UseDepthCSV = [];    % Use a csv containing depths for tetrodes
TetrodeTargets = []; % 0 indicates tetrode Target #1, 1 indicates tetrode Target #2
nCSCs = 24;          % Number of continuous sampling channels (Typically 24 TTs+4 refs)
TimeOnTrack = [];
TimeOffTrack = [];
nSecGap = 25;        % number of seconds in recording gap to presume session has ended.
HasHCTheta = [];     % 1 indicates an auxilliary HC theta electrode was included.  This affects the patch panel configuration on Cheetah.
ThetaCSC = [];
PostFeed = [];
nPellets = [];       % the number of pellets delivered at each zone
FeederDelayList = [1:30];% the delay of each zone
FeederProbList = [1]; % the probability of reward in each zone
Blocks = [];
Nudges = [];
Weight = [];         % the weight of the rat in grams
Note1=[];            % document any unusual events, task malfunctions, or unusual behavior (e.g. lost tracking lap 20, feeder misfires lap 20, ghost pixels, rat fell off track lap 20 etc).
Note2=[];
Note3=[];
addUnderscored=false;
process_varargin(varargin);
pushdir(fd);

assert(exist(fd, 'dir')==7, 'Cannot find directory %s.', fd);

[~, SSN, ~] = fileparts(fd);

%-----------------------
% DATAFILE
%-----------------------

datafn = FindFiles('RR-*.mat','Checksubdirs',0);
if length(datafn)>1
    for s = 1 : length(datafn)
        disp('Multiple RR data files.')
        sd0 = load(datafn{s});
        nReps = ceil(((sd0.TotalLaps+1)*4)/length(sd0.nPellets));
        nPellets = repmat(sd0.nPellets,1,nReps);
        nPellets = nPellets(1:length(sd0.ZoneIn));
        sd0.nPellets = nPellets;

        FeederList = repmat(sd0.FeederList,1,sd0.TotalLaps+1);
        FeederList = FeederList(1:length(sd0.ZoneIn));
        sd0.FeederList = FeederList;
        sd0.FeederDelay = sd0.FeederDelay(1:length(sd0.ZoneIn));
        sd0.Subsession = s;
        laps = repmat([1:length(sd0.ZoneIn)],4,1);
        laps = laps(:);
        sd0.Laps = laps(1:length(sd0.ZoneIn));
        
        sd(s,1) = sd0;
    end
else
    disp('Single-session restaurant row.')
    sd = load(datafn{1});
    nReps = ceil(((sd.TotalLaps+1)*4)/length(sd.nPellets));
    nPellets = repmat(sd.nPellets,1,nReps);
    nPellets = nPellets(1:length(sd.ZoneIn));
    sd.nPellets = nPellets;
    FeederList = repmat(sd.FeederList,1,sd.TotalLaps+1);
    FeederList = FeederList(1:length(sd.ZoneIn));
    sd.FeederList = FeederList;
    sd.FeederDelay = sd.FeederDelay(1:length(sd.ZoneIn));
    sd.Subsession = 1;
    
    laps = repmat([1:length(sd.ZoneIn)],4,1);
    laps = laps(:)';
    sd.Laps = laps(1:length(sd.ZoneIn));
end

disp(['Multiplying timestamps by ' num2str(timeBase) '...'])
for f = 1 : length(sd)
    sd(f).EnteringZoneTime = sd(f).EnteringZoneTime*timeBase;
    sd(f).ExitZoneTime = sd(f).ExitZoneTime*timeBase;
    sd(f).EnteringCPTime = sd(f).EnteringZoneTime;
    sd(f).ExitingCPTime = sd(f).EnteringZoneTime+VTEtime;
    if isfield(sd(f),'ToneTimes')
        sd(f).ToneTimes = sd(f).ToneTimes*timeBase;
    end
    if isfield(sd(f),'SessionStartTime')
        sd(f).SessionStartTime = sd(f).SessionStartTime*timeBase;
    end
    if isfield(sd(f),'SessionEndTime')
        sd(f).SessionEndTime = sd(f).SessionEndTime*timeBase;
    end
    sd(f).FeederTimes = sd(f).FeederTimes*timeBase;
end

%------------------------
% VIDEO TRACKING
%------------------------
W = warning();
warning off MATLAB:unknownObjectNowStruct
vtfn = fullfile(fd, [SSN '-vt.mat']);
if ~(exist(vtfn, 'file')==2)
    disp('Creating -VT.mat file...')
    nvtfile = FindFiles('*.nvt');
    unzipped = false;
    if isempty(nvtfile)
        zipfile = FindFiles('*.zip');
        filesPre = FindFiles('*.*','CheckSubdirs',false);
        if ~isempty(zipfile)
            unzip(zipfile{1})
            unzipped = true;
        end
        filesPost = FindFiles('*.*','CheckSubdirs',false);
        newFiles = filesPost(~ismember(filesPost,filesPre));

        nvtfile = FindFiles('*.nvt');
    end
    
    [x,y,phi] = LoadVT_lumrg(nvtfile{1});
    save([SSN '-vt.mat'],'x','y','phi')
    disp('-VT.mat file created.')
    if unzipped
        for iF = 1 : length(newFiles)
            delete(newFiles{iF});
        end
    end
end
   
if exist(vtfn, 'file')
	load(vtfn);
	if exist('Vt', 'var'), x = Vt.x; y = Vt.y; end
	if isstruct(x), x = tsd(x); end
	if isstruct(y), y = tsd(y); end
	if exist('phi', 'var') && isstruct(phi), phi = tsd(phi); end
    for f = 1 : length(sd)
        sd(f).x = x;
        sd(f).y = y;
    end
end

warning(W);

%-----------------------
% KEYS
%-----------------------
if useKeys
    keysfn = [strrep(SSN, '-', '_') '_keys'];
    if ~(exist(keysfn, 'file')==2)
        
        %GET TIME ON TRACK, OFF TRACK
        disp('Obtaining TimeOnTrack, TimeOffTrack information... ')
        tracking = load([SSN '-vt.mat']);
        x = tracking.x;
        y = tracking.y;
        
        if isfield(sd,'SessionStartTime')
            SessionStartTime = nan(length(sd),1);
            for iS=1:length(sd)
                SessionStartTime(iS) = sd(iS).SessionStartTime;
            end
            TimeOnTrack = min(SessionStartTime);
        else
            TimeOnTrack = min(x.range);
        end
        
        if strncmpi(Protocol,'Hyp',3)
            disp(['Inferring session end time from last >' num2str(nSecGap) 's gap in recording...']);
            TimeOffTrack = findRRendTime(vtfn,'startTime',TimeOnTrack,'nSec',nSecGap);
        else
            TimeOffTrack = max(x.range);
        end
        
        disp(sprintf('No keys file. Generating %s.',keysfn))
        RR_CreateKeys('Behavior', Behavior,...
            'Tones',Tones,...
            'Condition',Condition,...
            'Dose',Dose,...
            'Protocol',Protocol,...
            'Target',Target,...
            'Target2',Target2,...
            'Target3',Target3,...
            'Target4',Target4,...
            'Target5',Target5,...
            'Target6',Target6,...
            'TetrodeDepths',TetrodeDepths,...
            'UseDepthCSV',UseDepthCSV,...
            'TetrodeTargets',TetrodeTargets,...
            'nCSCs',nCSCs,...
            'CSCReference',CSCReference,...
            'TimeOnTrack',TimeOnTrack,...
            'TimeOffTrack',TimeOffTrack,...
            'HasHCTheta',HasHCTheta,...
            'ThetaCSC',ThetaCSC,...
            'PostFeed',PostFeed,...
            'nPellets',nPellets,...
            'FeederDelayList',FeederDelayList,...
            'FeederProbList',FeederProbList,...
            'Blocks',Blocks,...
            'Nudges',Nudges,...
            'Weight',Weight,...
            'Note1',Note1,...
            'Note2',Note2,...
            'Note3',Note3);
    end
    assert(exist([keysfn '.m'], 'file')==2, 'Cannot find keys file %s.', keysfn);
    eval(keysfn)
    disp('Experiment keys...')
%     for f = 1 : length(sd)
%         sd(f).ExpKeys = ExpKeys;
%         sd(f).ExpKeys.SSN = SSN;
%         sd(f).ExpKeys.fd = fd;
%     end
    eval('ExpKeys');
    for s = 1 : length(sd)
        sd(s).ExpKeys = ExpKeys;
        sd(s).ExpKeys.SSN = SSN;
        sd(s).ExpKeys.fd = fd;
    end
    
    assert(~iscell(ExpKeys.Behavior), 'Multiple Behaviors');
else
    ExpKeys.TimeOnTrack = 0;
    ExpKeys.TimeOffTrack = inf;
end


if length(sd)>1
    if isfield(sd,'SessionStartTime')
        disp('Setting subsession-specific on/off track times')
        for iSubsess = 1 : length(sd)-1
            StartTime(iSubsess) = sd(iSubsess).SessionStartTime;
            EndTime(iSubsess) = sd(iSubsess+1).SessionStartTime;
        end
        StartTime(length(sd)) = sd(length(sd)).SessionStartTime;
        EndTime(length(sd)) = sd(length(sd)).ExpKeys.TimeOffTrack;

        for iSubsess = 1 : length(sd)
            sd(iSubsess).SubsessOnTrack = StartTime(iSubsess);
            sd(iSubsess).SubsessOffTrack = EndTime(iSubsess);
        end
    else
        for iSubsess = 1 : length(sd)
            sd(iSubsess).SubsessOnTrack = nan;
            sd(iSubsess).SubsessOffTrack = nan;
        end
    end
else
    sd.SubsessOnTrack = sd.ExpKeys.TimeOnTrack;
    sd.SubsessOffTrack = sd.ExpKeys.TimeOffTrack;
end

% Create world.
disp('Building world...')
disp('Feeder locations...')
uniqueFs = unique(sd.FeedersFired);
World.FeederLocations.x = nan(max(uniqueFs),1);
World.FeederLocations.y = nan(max(uniqueFs),1);
for iF=1:length(uniqueFs)
    World.FeederLocations.x(uniqueFs(iF)) = nanmedian(sd.x.data(sd.FeederTimes(sd.FeedersFired==uniqueFs(iF))));
    World.FeederLocations.y(uniqueFs(iF)) = nanmedian(sd.y.data(sd.FeederTimes(sd.FeedersFired==uniqueFs(iF))));
end
disp('Zone boundary locations...')
uniqueZones = unique(sd.ZoneIn);
World.ZoneLocations.x = nan(max(uniqueZones),1);
World.ZoneLocations.y = nan(max(uniqueZones),1);
for iZ=1:length(uniqueZones)
    World.ZoneLocations.x(uniqueZones(iZ)) = nanmedian(sd.x.data(sd.EnteringZoneTime(sd.ZoneIn==uniqueZones(iZ))));
    World.ZoneLocations.y(uniqueZones(iZ)) = nanmedian(sd.y.data(sd.EnteringZoneTime(sd.ZoneIn==uniqueZones(iZ))));
end
disp('Maze center locations...')
World.MazeCenter.x = nanmedian(World.ZoneLocations.x);
World.MazeCenter.y = nanmedian(World.ZoneLocations.x);

sd(:).World = World;


%-------------------------
% EVENTS
%-------------------------
if useEvents
    disp('Processing events... ')
    eventsfn = fullfile(fd, [SSN '-events.Nev']);
    assert(exist(eventsfn, 'file')==2, 'Cannot find events file %s.', eventsfn);
end
%-------------------------
% SPIKES
%-------------------------
disp('Adding spike train information... ')
fc = FindFiles('*.t', 'CheckSubdirs', 0);
S = LoadSpikes(fc);
for iC = 1:length(S)
    S{iC} = S{iC}.restrict(min(sd.ExpKeys.TimeOnTrack), max(sd.ExpKeys.TimeOffTrack));
    D = S{iC}.data;
    S{iC} = ts(sort(D));
end

for f = 1 : length(sd)
    sd(f).S = S;
    sd(f).fc = fc;
    for iC = 1:length(fc)
        [~, sd(f).fn{iC}] = fileparts(sd(f).fc{iC});
        sd(f).fn{iC} = strrep(sd(f).fn{iC}, '_', '-');
    end
end

if addUnderscored
    disp('Adding underscore-t files...')
    fc0 = FindFiles('*._t','CheckSubdirs',0);
    S0 = LoadUnderscoredSpikes(fc0);
    
    for f0=1:length(sd)
        sd(f0).S_t = S0;
        sd(f0).fc_t = fc0;
        sd(f0).fn_t = cell(1,length(fc0));
        for iC = 1 : length(fc0)
            [~, fn_t] = fileparts(fc0{iC});
            sd(f0).fn_t{iC} = strrep(fn_t,'_','-');
        end
    end
end

if nargout<1
    save([SSN '-sd.mat'],'sd');
    disp(sprintf('sd saved to %s.',[fd '\' SSN '-sd.mat']))
end

popdir;

