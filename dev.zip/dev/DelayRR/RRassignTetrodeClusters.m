function I = RRassignTetrodeClusters(sd,varargin)
% Returns an s x n logical of the n, sd.fn file names that correspond to each
% of the s structures in sd.ExpKeys.Target.
% I = RRassignTetrodeClusters(sd)
% where     I       is an s x n logical with sd.fn-to-target assignments
%
%           sd      is a standard session data structure.
%
% OPTIONAL ARGUMENTS:
% ******************
% fn        (default sd.fn)         field with cluster file names
% 
%
%

fn = sd.fn;
process_varargin(varargin);

TTs = RRassignTetrodes(sd,'fn',fn);

uniqueTargets = unique(sd.ExpKeys.Target);
I = false(length(uniqueTargets),length(fn));

for iTT=1:length(TTs)
    for iTarget = 1 : length(uniqueTargets)
        Target = find(strcmpi(uniqueTargets{iTarget},sd.ExpKeys.Target));
        I(Target,iTT) = sd.ExpKeys.TetrodeTargets(TTs(iTT))==Target;
    end
end