function TTs = RRassignTetrodes(sd,varargin)
% Provides the tetrode number for each fn in sd.fn.
% TTs = RRassignTetrodes(sd)
% where     TTs     is n x 1 vector of tetrode numbers.
% 
%           sd      is a standard session data structure.
%
% OPTIONAL ARGUMENTS:
% ******************
% fn        (default sd.fn)     is the list of file names to assign
%                                   tetrodes.
%
%

fn = sd.fn;
process_varargin(varargin);

TTs = nan(1,length(fn));
for iClu = 1 : length(fn)
    str = fn{iClu};
    idTT = regexpi(str,'-TT[0-9]');
    TT_CLU = str(idTT+3:end);
    idCLU = regexpi(TT_CLU,'-');
    TTs(iClu) = str2double(TT_CLU(1:idCLU-1));
end