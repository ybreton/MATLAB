function KKwikCondition(varargin)
% KKwik entire condition.

root = pwd;
FD = '\FD'; % Features directory, where KKwik puts *.clu.* files.
fcTT = cell(1,24);
for iF=1:24
    fcTT{iF} = sprintf('TT%d.ntt',iF); % Tetrodes to autocut.
end
process_varargin(varargin);
pushdir(root);
disp(['Searching ' root ' for sessions to autocut.'])
%% Get the list of sessions to KKwik
disp('Getting list of sessions to KKwik.')
FD = regexprep(FD,'\\','\\\\'); % Find the backslashes, make them double backslashes.

ntt = FindFiles('*.ntt');
ntd = cell(length(ntt),1);
for iF=1:length(ntt); ntd{iF} = fileparts(ntt{iF}); end;
ntd = unique(ntd);
clu = FindFiles('*.clu.*');
cld = cell(length(clu),1);
for iF=1:length(clu); 
    fd = fileparts(clu{iF});
    delim = regexpi(fd,FD);
    cld{iF}=fd(1:max(delim)-1); 
end;
cld = unique(cld);

todo = ntd(~ismember(ntd,cld));
disp('Sessions to cut:')
for iF=1:length(todo)
    fd = todo{iF};
    delim = regexpi(fd,'\\');
    fd = fd(max(delim)+1:end);
    disp(fd);
end

%% Clean up as much as possible to liberate space.
disp('Cleaning up.')
ws = who;
ws = ws(~ismember(ws,{'todo' 'fcTT'}));
for s=1:length(ws)
    eval(['clear ' ws{s}])
end
clear s ws
% Only todo and fcTT should exist at this point.
%% Run clust batch on the sucker.
for iD=1:length(todo)
    pushdir(todo{iD});
    disp(['AUTOCUTTING SESSION ' todo{iD}])
    RunClustBatch('fcTT',fcTT);
    popdir;
    disp([num2str(length(todo)-iD) ' sessions remain to autocut.'])
end
%%
popdir;