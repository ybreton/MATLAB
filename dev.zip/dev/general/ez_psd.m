function [f,d,a] = ez_psd(xt)
%
%
%
%
Fs = 1/xt.dt;
L = length(xt.data);
NFFT = 2^nextpow2(L);
Y = fft(xt.data,NFFT)/L;
f = (Fs/2*linspace(0,1,NFFT/2+1))';
a = 2*abs(Y(1:NFFT/2+1));
d = a./f;