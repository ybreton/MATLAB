function params = heavisidefit(x,y,k,varargin)
%
%
%
%

debug=false;
process_varargin(varargin);

options = optimset('display','off','algorithm','interior-point');

param0(1) = median(x);
param0(3) = 1;
param0(4) = 0;

if k>3
    A = [0 -1 1];
    b = 0;
else
    A = [];
    b = [];
end
Aeq = [];
beq = [];
lb = [min(x) 0 0];
ub = [max(x) 1 1];

param0 = param0(1:k);
lb = lb(1:k);
ub = ub(1:k);

if k>1
    s = [0;1;-1];
    param0 = param0([1 3:k]);
    lb = lb([1 3:k]);
    ub = ub([1 3:k]);
    
    [param(:,1),SSerr(1)] = fmincon(@(param) errFunc(param,0,x,y,k,debug),param0,A,b,Aeq,beq,lb,ub,[],options);
    [param(:,2),SSerr(2)] = fmincon(@(param) errFunc(param,1,x,y,k,debug),param0,A,b,Aeq,beq,lb,ub,[],options);
    [param(:,3),SSerr(3)] = fmincon(@(param) errFunc(param,-1,x,y,k,debug),param0,A,b,Aeq,beq,lb,ub,[],options);
    
    [SSerrMin,idMin] = min(SSerr);
    param = param(:,idMin);
    s = s(idMin);
else
    param = fminsearch(@(param) errFunc(param,1,x,y,k,debug),param0);
    s = 1;
end
if k>0
    params(1) = param(1);
end
if k>1
    params(2) = s;
end
if k>2
    params(3) = param(2);
end
if k>3
    params(4) = param(3);
end

if debug
    cla
    hold on
    [ph,eh]=plot_grouped_Y(x,y,'dist','binomial');
    hold off
    hold on
    set(ph,'markerfacecolor','k')
    set(ph,'markeredgecolor','k')
    plot(sort(x),heavisideval(params,sort(x)),'r-')
    hold off
    drawnow
end

function SSerr = errFunc(b,s,x,y,k,debug)
if k>0
    params(1) = b(1);
end
if k>1
    params(2) = s;
end
if k>2
    params(3) = b(2);
end
if k>3
    params(4) = b(3);
end

yhat = heavisideval(params,x);

dev = y-yhat;

SSerr = dev(:)'*dev(:);

if debug
    cla
    hold on
    [ph,eh]=plot_grouped_Y(x,y,'dist','binomial');
    hold off
    hold on
    set(ph,'markerfacecolor','k')
    set(ph,'markeredgecolor','k')
    plot(sort(x),heavisideval(params,sort(x)),'r-')
    hold off
    drawnow
end