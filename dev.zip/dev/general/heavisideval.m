function y = heavisideval(b,x)
%
%
%
%
if length(b)>0
    xc = b(1);
else
    xc = 0;
end
if length(b)>1
    s  = sign(b(2));
else
    s = 1;
end
if length(b)>2
    maximum = b(3);
else
    maximum = 1;
end
if length(b)>3
    minimum = b(4);
else
    minimum = 0;
end

x0 = (x-xc)*s;

y = heaviside(x0)*(maximum-minimum)+minimum;