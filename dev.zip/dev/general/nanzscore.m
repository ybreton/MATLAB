function Z = nanzscore(X,flag,dim)
%
%
%
%

if nargin<3
    dim=1;
end
if nargin<2
    flag=0;
end

assert(dim<=length(size(X)),['X must have at least ' num2str(dim) ' dimensions.']);
assert((flag==0||flag==1),'flag must be a boolean.');


sz = size(X);
reps = ones(1,length(sz));
reps(dim) = sz(dim);

M = repmat(nanmean(X,dim),reps);
S = repmat(nanstd(X,flag,dim),reps);

Z = (X-M)./S;