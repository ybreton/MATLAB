function [b,SSerr] = sigmoidfit(x,y,k,varargin)
% Fits a sigmoid by least-squares.
% Yhat = (x^b(2)/(x^b(2) + b(1)^b(2)))*(b(3)-b(4))+b(4)
%
%

debug = false;
process_varargin(varargin);
if debug
    fh = figure;
end

options = optimset('display','off','MaxFunEvals',10^4,'TolFun',10^-6,'TolX',10^-6);
if k>0
    b0(1) = (max(x)-min(x))/2+min(x);
end
if k>1
    beta = glmfit(x(y>0),log10(y(y>0)),'normal');
    b0(2) = beta(2);
end
if k>2
    b0(3) = max(y);
end
if k>3
    b0(4) = min(y);
end
[b,SSerr] = fminsearch(@(b) errorVar(b,x,y,debug),b0,options);
b = b(:);

if debug
    close(fh)
end


function SSerr = errorVar(b,x,y,debug)
Yhat = sigmoidval(b,x);
dev = Yhat-y;
SSerr = dev(:)'*dev(:);

if debug
    cla
    hold on
    plot(x,y,'ko')
    plot(sort(x),sigmoidval(b,sort(x)),'r-')
    hold off
    drawnow
end