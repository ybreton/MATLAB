function Yhat = sigmoidval(b,x)
switch length(b)
    case 2
        b(3) = 1;
        b(4) = 0;
    case 3
        b(4) = 0;
end

Xhm = b(1);
G = b(2);
yMax = b(3);
yMin = b(4);

Y0 = x.^G./(x.^G+Xhm.^G);
Yhat = Y0*(yMax-yMin)+yMin;
Yhat = max(min(yMax, Yhat), yMin);